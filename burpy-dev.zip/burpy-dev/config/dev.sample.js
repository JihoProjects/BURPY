module.exports = {
  googleClientID:'...',
  googleClientSecret: '...',
  naverClientID: '...',
  naverClientSecret: '...',
  twitterClientID: '...',
  twitterClientSecret: '...',
  mongoURI: 'mongodb://localhost:27017/burpy-local', // local
  cookieKey: '{type random string here}',
  redirectDomain: 'http://localhost:3000',
  ICServerURL: 'http://localhost:8000',
  awsAccessKeyId: '...',
  awsSecretAccessKey: '...'
};
