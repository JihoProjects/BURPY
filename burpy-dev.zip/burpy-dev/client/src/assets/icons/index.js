export { default as LogoIcon } from './LogoIcon';
export { default as BeerIcon } from './BeerIcon';
export { default as PhotoIcon } from './PhotoIcon';
export { default as SodaIcon } from './SodaIcon';
export { default as CoffeeIcon } from './CoffeeIcon';
export { default as WhiskeyIcon } from './WhiskeyIcon';