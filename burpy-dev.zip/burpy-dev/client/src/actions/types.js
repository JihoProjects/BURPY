export const FETCH_USER = 'fetch_user';
export const UPDATE_SEARCH = 'update_search';
export const FETCH_SEARCH_ITEMS = 'fetch_search_items';